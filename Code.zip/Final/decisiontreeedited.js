//this is the actual decision tree file for linking with server 
var DecisionTree = require('decision-tree');
var fs = require('fs');

var jan = require('./jan.json');
var feb = require('./feb.json');
var mar = require('./mar.json');
var apr = require('./apr.json');
var may = require('./may.json');
var jun = require('./jun.json');
var jul = require('./jul.json');
var aug = require('./aug.json');
var sep = require('./sep.json');
var oct = require('./oct.json');
var nov = require('./nov.json');
var dec = require('./dec.json');



var compiled = jan.concat(feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec);

//create variables to check for delay and categorize hour of departure

for (i=0;i<compiled.length;i++){
    if (Number(compiled[i].ArrDelayNew)>=15) {compiled[i].delayCheck = '1';}
    else {compiled[i].delayCheck = '0';}
    if (compiled[i].CrsDepTime.length<=2) {compiled[i].depHr = 0;}
    else if (compiled[i].CrsDepTime.length==3) {compiled[i].depHr = compiled[i].CrsDepTime[0];}
    else if (compiled[i].CrsDepTime.length==4) {compiled[i].depHr = compiled[i].CrsDepTime[0]+compiled[i].CrsDepTime[1];}
}


//use 50% of data for training, 50% for testing 
trainingarray = [];
for (i=0;i<compiled.length;i+=2){
    tempobject = {};
    tempobject.Awnd = Number(compiled[i].Awnd);
    tempobject.Carrier = compiled[i].Carrier;
    tempobject.DayofWeek = compiled[i].DayOfWeek;
    tempobject.delayCheck = compiled[i].delayCheck; 
    tempobject.depHr = compiled[i].depHr;
    tempobject.Dest = compiled[i].Dest;
    tempobject.Month = compiled[i].Month; 
    tempobject.Origin = compiled[i].Origin;
    tempobject.Snow = Number(compiled[i].Snow);
    tempobject.Snwd = Number(compiled[i].Snwd);
    tempobject.Tavg = Number(compiled[i].Tavg);
    tempobject.Tmax = Number(compiled[i].Tmax);
    tempobject.Tmin = Number(compiled[i].Tmin);

    trainingarray.push(tempobject);
}

testarray = [];
for (i=1;i<compiled.length;i+=2){
    tempobject = {};
    tempobject.Awnd = Number(compiled[i].Awnd);
    tempobject.Carrier = compiled[i].Carrier;
    tempobject.DayofWeek = compiled[i].DayOfWeek;
    tempobject.delayCheck = compiled[i].delayCheck; 
    tempobject.depHr = compiled[i].depHr;
    tempobject.Dest = compiled[i].Dest;
    tempobject.Month = compiled[i].Month; 
    tempobject.Origin = compiled[i].Origin;
    tempobject.Snow = Number(compiled[i].Snow);
    tempobject.Snwd = Number(compiled[i].Snwd);
    tempobject.Tavg = Number(compiled[i].Tavg);
    tempobject.Tmax = Number(compiled[i].Tmax);
    tempobject.Tmin = Number(compiled[i].Tmin);

    testarray.push(tempobject);
}

var class_name = "delayCheck";
var features = ["Awnd","Carrier","DayofWeek","depHr","Dest","Month","Origin","Snow","Snwd","Tavg","Tmax","Tmin"];


//use the following code to test when someone inputs
/*var predicted_class = dt.predict({
    Awnd:6.04,
    Carrier:'AA',
    DayofWeek:4,
    depHr:16,
    Dest:'ATL',
    Month:'1',
    Origin:'LAX',
    Snow:0,
    Snwd:0,
    Tavg:56,
    Tmax:58,
    Tmin:53,
}); */

var decisiontree = {};

decisiontree.createTree = function(){
console.log('creating tree');
dt = new DecisionTree(trainingarray, class_name, features);

};

decisiontree.predict = function(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12){
    
var predicted_class = dt.predict({
    Awnd:arg1,
    Carrier:arg2,
    DayofWeek:arg3,
    depHr:arg4,
    Dest:arg5,
    Month:arg6,
    Origin:arg7,
    Snow:arg8,
    Snwd:arg9,
    Tavg:arg10,
    Tmax:arg11,
    Tmin:arg12
});
var finalpredict = 0;
console.log(predicted_class);
if (predicted_class == 1) {
    finalpredict = 1;
}
console.log('predicting' + finalpredict);
return finalpredict;
};

//var accuracy = dt.evaluate(testarray); //for model validation: 72%

module.exports = decisiontree;

