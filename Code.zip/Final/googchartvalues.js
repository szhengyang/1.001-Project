
var jan = require('./jan.json');
var feb = require('./feb.json');
var mar = require('./mar.json');
var apr = require('./apr.json');
var may = require('./may.json');
var jun = require('./jun.json');
var jul = require('./jul.json');
var aug = require('./aug.json');
var sep = require('./sep.json');
var oct = require('./oct.json');
var nov = require('./nov.json');
var dec = require('./dec.json');

var compiled = jan.concat(feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec);
console.log(compiled.length);



var AAotcount=0;
var ASotcount=0;
var B6otcount=0;
var DLotcount=0;
var NKotcount=0;
var UAotcount=0;
var WNotcount=0;


var AAdepdelaySum=0; var AAdepcounter=0; var AAcatcounter=0; AAarrdelaySum=0;AAcarrierdelaySum=0;AAlateaircraftdelaySum=0;AAnasdelaySum=0;AAsecuritydelaySum=0;AAweatherdelaySum=0;
var ASdepdelaySum=0; var ASdepcounter=0; var AScatcounter=0; ASarrdelaySum=0;AScarrierdelaySum=0;ASlateaircraftdelaySum=0;ASnasdelaySum=0;ASsecuritydelaySum=0;ASweatherdelaySum=0;
var B6depdelaySum=0; var B6depcounter=0; var B6catcounter=0; B6arrdelaySum=0;B6carrierdelaySum=0;B6lateaircraftdelaySum=0;B6nasdelaySum=0;B6securitydelaySum=0;B6weatherdelaySum=0;
var DLdepdelaySum=0; var DLdepcounter=0; var DLcatcounter=0; DLarrdelaySum=0;DLcarrierdelaySum=0;DLlateaircraftdelaySum=0;DLnasdelaySum=0;DLsecuritydelaySum=0;DLweatherdelaySum=0;
var NKdepdelaySum=0; var NKdepcounter=0; var NKcatcounter=0; NKarrdelaySum=0;NKcarrierdelaySum=0;NKlateaircraftdelaySum=0;NKnasdelaySum=0;NKsecuritydelaySum=0;NKweatherdelaySum=0;
var UAdepdelaySum=0; var UAdepcounter=0; var UAcatcounter=0; UAarrdelaySum=0;UAcarrierdelaySum=0;UAlateaircraftdelaySum=0;UAnasdelaySum=0;UAsecuritydelaySum=0;UAweatherdelaySum=0;
var WNdepdelaySum=0; var WNdepcounter=0; var WNcatcounter=0; WNarrdelaySum=0;WNcarrierdelaySum=0;WNlateaircraftdelaySum=0;WNnasdelaySum=0;WNsecuritydelaySum=0;WNweatherdelaySum=0;

//find flight count for each airline 
for (i=0;i<compiled.length;i++){
    if (Number(compiled[i].ArrDelayNew)<15){
        if (compiled[i].Carrier=='AA') AAotcount++;
        if (compiled[i].Carrier=='AS') ASotcount++;
        if (compiled[i].Carrier=='B6') B6otcount++;
        if (compiled[i].Carrier=='DL') DLotcount++;
        if (compiled[i].Carrier=='NK') NKotcount++;
        if (compiled[i].Carrier=='UA') UAotcount++;
        if (compiled[i].Carrier=='WN') WNotcount++;
    }
}

/*
if depdelay>15 --> delayed departure
if arrdelay>15 --> delayed arrival & overall flight recorded as 'delayed' as long as arrdelay>15
*/
//find depdelay &count 
for (i=0;i<compiled.length;i++){
    if (Number(compiled[i].DepDelayNew)>=15 && Number(compiled[i].ArrDelayNew)>=15 && Number(compiled[i].ArrDelayNew)==Number(compiled[i].CarrierDelay)+Number(compiled[i].LateAircraftDelay)+Number(compiled[i].NasDelay)+Number(compiled[i].SecurityDelay)+Number(compiled[i].WeatherDelay)){
        if (compiled[i].Carrier=='AA') AAdepcounter++;
        if (compiled[i].Carrier=='AS') ASdepcounter++;
        if (compiled[i].Carrier=='B6') B6depcounter++;
        if (compiled[i].Carrier=='DL') DLdepcounter++;
        if (compiled[i].Carrier=='NK') NKdepcounter++;
        if (compiled[i].Carrier=='UA') UAdepcounter++;
        if (compiled[i].Carrier=='WN') WNdepcounter++;
    }
}

//filter arrdelay flights with full data on delay categories 
for (i=0;i<compiled.length;i++){
if (Number(compiled[i].ArrDelayNew)>=15 && Number(compiled[i].ArrDelayNew)==Number(compiled[i].CarrierDelay)+Number(compiled[i].LateAircraftDelay)+Number(compiled[i].NasDelay)+Number(compiled[i].SecurityDelay)+Number(compiled[i].WeatherDelay)){
    if (compiled[i].Carrier=='AA') {
        AAdepdelaySum += Number(compiled[i].DepDelayNew); 
        AAcatcounter++;
        AAarrdelaySum += Number(compiled[i].ArrDelayNew);
        AAcarrierdelaySum += Number(compiled[i].CarrierDelay);
        AAlateaircraftdelaySum += Number(compiled[i].LateAircraftDelay);
        AAnasdelaySum += Number(compiled[i].NasDelay);
        AAsecuritydelaySum += Number(compiled[i].SecurityDelay);
        AAweatherdelaySum += Number(compiled[i].WeatherDelay);
    }
    else if (compiled[i].Carrier=='AS') 
        {
            ASdepdelaySum += Number(compiled[i].DepDelayNew); 
            AScatcounter++;
            ASarrdelaySum += Number(compiled[i].ArrDelayNew);
            AScarrierdelaySum += Number(compiled[i].CarrierDelay);
            ASlateaircraftdelaySum += Number(compiled[i].LateAircraftDelay);
            ASnasdelaySum += Number(compiled[i].NasDelay);
            ASsecuritydelaySum += Number(compiled[i].SecurityDelay);
            ASweatherdelaySum += Number(compiled[i].WeatherDelay);
        }
    else if (compiled[i].Carrier=='B6') 
        {
            B6depdelaySum += Number(compiled[i].DepDelayNew); 
            B6catcounter++;
            B6arrdelaySum += Number(compiled[i].ArrDelayNew);
            B6carrierdelaySum += Number(compiled[i].CarrierDelay);
            B6lateaircraftdelaySum += Number(compiled[i].LateAircraftDelay);
            B6nasdelaySum += Number(compiled[i].NasDelay);
            B6securitydelaySum += Number(compiled[i].SecurityDelay);
            B6weatherdelaySum += Number(compiled[i].WeatherDelay);
        }
    else if (compiled[i].Carrier=='DL') 
        {
            DLdepdelaySum += Number(compiled[i].DepDelayNew); 
            DLcatcounter++;
            DLarrdelaySum += Number(compiled[i].ArrDelayNew);
            DLcarrierdelaySum += Number(compiled[i].CarrierDelay);
            DLlateaircraftdelaySum += Number(compiled[i].LateAircraftDelay);
            DLnasdelaySum += Number(compiled[i].NasDelay);
            DLsecuritydelaySum += Number(compiled[i].SecurityDelay);
            DLweatherdelaySum += Number(compiled[i].WeatherDelay);
        }
            
    else if (compiled[i].Carrier=='NK') 
        {
            NKdepdelaySum += Number(compiled[i].DepDelayNew); 
            NKcatcounter++;
            NKarrdelaySum += Number(compiled[i].ArrDelayNew);
            NKcarrierdelaySum += Number(compiled[i].CarrierDelay);
            NKlateaircraftdelaySum += Number(compiled[i].LateAircraftDelay);
            NKnasdelaySum += Number(compiled[i].NasDelay);
            NKsecuritydelaySum += Number(compiled[i].SecurityDelay);
            NKweatherdelaySum += Number(compiled[i].WeatherDelay);
        }
    else if (compiled[i].Carrier=='UA') 
        {
            UAdepdelaySum += Number(compiled[i].DepDelayNew); 
            UAcatcounter++;
            UAarrdelaySum += Number(compiled[i].ArrDelayNew);
            UAcarrierdelaySum += Number(compiled[i].CarrierDelay);
            UAlateaircraftdelaySum += Number(compiled[i].LateAircraftDelay);
            UAnasdelaySum += Number(compiled[i].NasDelay);
            UAsecuritydelaySum += Number(compiled[i].SecurityDelay);
            UAweatherdelaySum += Number(compiled[i].WeatherDelay);
        }
    else if (compiled[i].Carrier=='WN') 
        {
            WNdepdelaySum += Number(compiled[i].DepDelayNew); 
            WNcatcounter++;
            WNarrdelaySum += Number(compiled[i].ArrDelayNew);
            WNcarrierdelaySum += Number(compiled[i].CarrierDelay);
            WNlateaircraftdelaySum += Number(compiled[i].LateAircraftDelay);
            WNnasdelaySum += Number(compiled[i].NasDelay);
            WNsecuritydelaySum += Number(compiled[i].SecurityDelay);
            WNweatherdelaySum += Number(compiled[i].WeatherDelay);
        }
    }
}

var AAdepdelayAvg = AAdepdelaySum/AAcatcounter; var AAarrdelayAvg = AAarrdelaySum/AAcatcounter; var AAcarrierdelayAvg = AAcarrierdelaySum/AAcatcounter; var AAlateaircraftdelayAvg = AAlateaircraftdelaySum/AAcatcounter; var AAnasdelayAvg = AAnasdelaySum/AAcatcounter; var AAsecuritydelayAvg = AAsecuritydelaySum/AAcatcounter; var AAweatherdelayAvg = AAweatherdelaySum/AAcatcounter; 
var ASdepdelayAvg = ASdepdelaySum/AScatcounter; var ASarrdelayAvg = ASarrdelaySum/AScatcounter; var AScarrierdelayAvg = AScarrierdelaySum/AScatcounter; var ASlateaircraftdelayAvg = ASlateaircraftdelaySum/AScatcounter; var ASnasdelayAvg = ASnasdelaySum/AScatcounter; var ASsecuritydelayAvg = ASsecuritydelaySum/AScatcounter; var ASweatherdelayAvg = ASweatherdelaySum/AScatcounter; 
var B6depdelayAvg = B6depdelaySum/B6catcounter; var B6arrdelayAvg = B6arrdelaySum/B6catcounter; var B6carrierdelayAvg = B6carrierdelaySum/B6catcounter; var B6lateaircraftdelayAvg = B6lateaircraftdelaySum/B6catcounter; var B6nasdelayAvg = B6nasdelaySum/B6catcounter; var B6securitydelayAvg = B6securitydelaySum/B6catcounter; var B6weatherdelayAvg = B6weatherdelaySum/B6catcounter; 
var DLdepdelayAvg = DLdepdelaySum/DLcatcounter; var DLarrdelayAvg = DLarrdelaySum/DLcatcounter; var DLcarrierdelayAvg = DLcarrierdelaySum/DLcatcounter; var DLlateaircraftdelayAvg = DLlateaircraftdelaySum/DLcatcounter; var DLnasdelayAvg = DLnasdelaySum/DLcatcounter; var DLsecuritydelayAvg = DLsecuritydelaySum/DLcatcounter; var DLweatherdelayAvg = DLweatherdelaySum/DLcatcounter; 
var NKdepdelayAvg = NKdepdelaySum/NKcatcounter; var NKarrdelayAvg = NKarrdelaySum/NKcatcounter; var NKcarrierdelayAvg = NKcarrierdelaySum/NKcatcounter; var NKlateaircraftdelayAvg = NKlateaircraftdelaySum/NKcatcounter; var NKnasdelayAvg = NKnasdelaySum/NKcatcounter; var NKsecuritydelayAvg = NKsecuritydelaySum/NKcatcounter; var NKweatherdelayAvg = NKweatherdelaySum/NKcatcounter; 
var UAdepdelayAvg = UAdepdelaySum/UAcatcounter; var UAarrdelayAvg = UAarrdelaySum/UAcatcounter; var UAcarrierdelayAvg = UAcarrierdelaySum/UAcatcounter; var UAlateaircraftdelayAvg = UAlateaircraftdelaySum/UAcatcounter; var UAnasdelayAvg = UAnasdelaySum/UAcatcounter; var UAsecuritydelayAvg = UAsecuritydelaySum/UAcatcounter; var UAweatherdelayAvg = UAweatherdelaySum/UAcatcounter; 
var WNdepdelayAvg = WNdepdelaySum/WNcatcounter; var WNarrdelayAvg = WNarrdelaySum/WNcatcounter; var WNcarrierdelayAvg = WNcarrierdelaySum/WNcatcounter; var WNlateaircraftdelayAvg = WNlateaircraftdelaySum/WNcatcounter; var WNnasdelayAvg = WNnasdelaySum/WNcatcounter; var WNsecuritydelayAvg = WNsecuritydelaySum/WNcatcounter; var WNweatherdelayAvg = WNweatherdelaySum/WNcatcounter; 


console.log(AAotcount, ASotcount, B6otcount, DLotcount, NKotcount, UAotcount, WNotcount);
console.log(AAcatcounter,AScatcounter,B6catcounter,DLcatcounter,NKcatcounter,UAcatcounter,WNcatcounter);
console.log(AAdepcounter,ASdepcounter,B6depcounter,DLdepcounter,NKdepcounter,UAdepcounter,WNdepcounter);
console.log(AAdepdelayAvg,ASdepdelayAvg,B6depdelayAvg,DLdepdelayAvg,NKdepdelayAvg,UAdepdelayAvg,WNdepdelayAvg);
console.log(AAarrdelayAvg,ASarrdelayAvg,B6arrdelayAvg,DLarrdelayAvg,NKarrdelayAvg,UAarrdelayAvg,WNarrdelayAvg);
console.log(AAcarrierdelayAvg,AScarrierdelayAvg,B6carrierdelayAvg,DLcarrierdelayAvg,NKcarrierdelayAvg,UAcarrierdelayAvg,WNcarrierdelayAvg);
console.log(AAlateaircraftdelayAvg,ASlateaircraftdelayAvg,B6lateaircraftdelayAvg,DLlateaircraftdelayAvg,NKlateaircraftdelayAvg,UAlateaircraftdelayAvg,WNlateaircraftdelayAvg);
console.log(AAnasdelayAvg,ASnasdelayAvg,B6nasdelayAvg,DLnasdelayAvg,NKnasdelayAvg,UAnasdelayAvg,WNnasdelayAvg);
console.log(AAsecuritydelayAvg,ASsecuritydelayAvg,B6securitydelayAvg,DLsecuritydelayAvg,NKsecuritydelayAvg,UAsecuritydelayAvg,WNsecuritydelayAvg);
console.log(AAweatherdelayAvg,ASweatherdelayAvg,B6weatherdelayAvg,DLweatherdelayAvg,NKweatherdelayAvg,UAweatherdelayAvg,WNweatherdelayAvg);



