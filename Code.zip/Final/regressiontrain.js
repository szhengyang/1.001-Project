var MLR =require('ml-regression-multivariate-linear');
var fs = require('fs');

var jan = require('./jan.json');
var feb = require('./feb.json');
var mar = require('./mar.json');
var apr = require('./apr.json');
var may = require('./may.json');
var jun = require('./jun.json');
var jul = require('./jul.json');
var aug = require('./aug.json');
var sep = require('./sep.json');
var oct = require('./oct.json');
var nov = require('./nov.json');
var dec = require('./dec.json');

var compiled = jan.concat(feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec);

for (i=0;i<compiled.length;i++){
    if (compiled[i].CrsDepTime.length<=2) {compiled[i].depHr = 0;}
    else if (compiled[i].CrsDepTime.length==3) {compiled[i].depHr = compiled[i].CrsDepTime[0];}
    else if (compiled[i].CrsDepTime.length==4) {compiled[i].depHr = compiled[i].CrsDepTime[0]+compiled[i].CrsDepTime[1];}
}


//use 50% of data for training, 50% for testing 
var trainingarray = [];
for (i=0;i<compiled.length;i+=2){
    trainingarray.push(compiled[i]);
}

var ytrain = [];
for (i=0;i<trainingarray.length;i++){
    ytrain[i]=[Number(trainingarray[i].ArrDelayNew)];
}

var xtrain = [];
for (i=0;i<trainingarray.length;i++){
    xvariables = [];
    if (trainingarray[i].Carrier == 'AA') {xvariables[0]=1;} else {xvariables[0]=0;}
    if (trainingarray[i].Carrier == 'AS') {xvariables[1]=1;} else {xvariables[1]=0;}
    if (trainingarray[i].Carrier == 'B6') {xvariables[2]=1;} else {xvariables[2]=0;}
    if (trainingarray[i].Carrier == 'DL') {xvariables[3]=1;} else {xvariables[3]=0;}
    if (trainingarray[i].Carrier == 'NK') {xvariables[4]=1;} else {xvariables[4]=0;}
    if (trainingarray[i].Carrier == 'UA') {xvariables[5]=1;} else {xvariables[5]=0;}
    if (trainingarray[i].Carrier == 'WN') {xvariables[6]=1;} else {xvariables[6]=0;}
    xvariables[7]=Number(trainingarray[i].Tmax);
    xvariables[8]=Number(trainingarray[i].Tmin);
    xvariables[9]=Number(trainingarray[i].Tavg);
    xvariables[10]=Number(trainingarray[i].Snwd);
    xvariables[11]=Number(trainingarray[i].Snow);
    if (trainingarray[i].Month == '1') {xvariables[12]=1;} else {xvariables[12]=0;}
    if (trainingarray[i].Month == '2') {xvariables[13]=1;} else {xvariables[13]=0;}
    if (trainingarray[i].Month == '3') {xvariables[14]=1;} else {xvariables[14]=0;}
    if (trainingarray[i].Month == '4') {xvariables[15]=1;} else {xvariables[15]=0;}
    if (trainingarray[i].Month == '5') {xvariables[16]=1;} else {xvariables[16]=0;}
    if (trainingarray[i].Month == '6') {xvariables[17]=1;} else {xvariables[17]=0;}
    if (trainingarray[i].Month == '7') {xvariables[18]=1;} else {xvariables[18]=0;}
    if (trainingarray[i].Month == '8') {xvariables[19]=1;} else {xvariables[19]=0;}
    if (trainingarray[i].Month == '9') {xvariables[20]=1;} else {xvariables[20]=0;}
    if (trainingarray[i].Month == '10') {xvariables[21]=1;} else {xvariables[21]=0;}
    if (trainingarray[i].Month == '11') {xvariables[22]=1;} else {xvariables[22]=0;}
    if (trainingarray[i].Month == '12') {xvariables[23]=1;} else {xvariables[23]=0;}
    if (trainingarray[i].DayofWeek == '1') {xvariables[24]=1;} else {xvariables[24]=0;}
    if (trainingarray[i].DayofWeek == '2') {xvariables[25]=1;} else {xvariables[25]=0;}
    if (trainingarray[i].DayofWeek == '3') {xvariables[26]=1;} else {xvariables[26]=0;}
    if (trainingarray[i].DayofWeek == '4') {xvariables[27]=1;} else {xvariables[27]=0;}
    if (trainingarray[i].DayofWeek == '5') {xvariables[28]=1;} else {xvariables[28]=0;}
    if (trainingarray[i].DayofWeek == '6') {xvariables[29]=1;} else {xvariables[29]=0;}
    if (trainingarray[i].DayofWeek == '7') {xvariables[30]=1;} else {xvariables[30]=0;}
    xvariables[31]=Number(trainingarray[i].Awnd);
    if (trainingarray[i].depHr == '0') {xvariables[32]=1;} else {xvariables[32]=0;}
    if (trainingarray[i].depHr == '1') {xvariables[33]=1;} else {xvariables[33]=0;}
    if (trainingarray[i].depHr == '2') {xvariables[34]=1;} else {xvariables[34]=0;}
    if (trainingarray[i].depHr == '3') {xvariables[35]=1;} else {xvariables[35]=0;}
    if (trainingarray[i].depHr == '4') {xvariables[36]=1;} else {xvariables[36]=0;}
    if (trainingarray[i].depHr == '5') {xvariables[37]=1;} else {xvariables[37]=0;}
    if (trainingarray[i].depHr == '6') {xvariables[38]=1;} else {xvariables[38]=0;}
    if (trainingarray[i].depHr == '7') {xvariables[39]=1;} else {xvariables[39]=0;}
    if (trainingarray[i].depHr == '8') {xvariables[40]=1;} else {xvariables[40]=0;}
    if (trainingarray[i].depHr == '9') {xvariables[41]=1;} else {xvariables[41]=0;}
    if (trainingarray[i].depHr == '10') {xvariables[42]=1;} else {xvariables[42]=0;}
    if (trainingarray[i].depHr == '11') {xvariables[43]=1;} else {xvariables[43]=0;}
    if (trainingarray[i].depHr == '12') {xvariables[44]=1;} else {xvariables[44]=0;}
    if (trainingarray[i].depHr == '13') {xvariables[45]=1;} else {xvariables[45]=0;}
    if (trainingarray[i].depHr == '14') {xvariables[46]=1;} else {xvariables[46]=0;}
    if (trainingarray[i].depHr == '15') {xvariables[47]=1;} else {xvariables[47]=0;}
    if (trainingarray[i].depHr == '16') {xvariables[48]=1;} else {xvariables[48]=0;}
    if (trainingarray[i].depHr == '17') {xvariables[49]=1;} else {xvariables[49]=0;}
    if (trainingarray[i].depHr == '18') {xvariables[50]=1;} else {xvariables[50]=0;}
    if (trainingarray[i].depHr == '19') {xvariables[51]=1;} else {xvariables[51]=0;}
    if (trainingarray[i].depHr == '20') {xvariables[52]=1;} else {xvariables[52]=0;}
    if (trainingarray[i].depHr == '21') {xvariables[53]=1;} else {xvariables[53]=0;}
    if (trainingarray[i].depHr == '22') {xvariables[54]=1;} else {xvariables[54]=0;}
    if (trainingarray[i].depHr == '23') {xvariables[55]=1;} else {xvariables[55]=0;}
    if (trainingarray[i].Origin == 'ATL') {xvariables[56]=1;} else {xvariables[56]=0;}
    if (trainingarray[i].Origin == 'LAX') {xvariables[57]=1;} else {xvariables[57]=0;}
    if (trainingarray[i].Origin == 'ORD') {xvariables[58]=1;} else {xvariables[58]=0;}
    if (trainingarray[i].Origin == 'DFW') {xvariables[59]=1;} else {xvariables[59]=0;}
    if (trainingarray[i].Origin == 'JFK') {xvariables[60]=1;} else {xvariables[60]=0;}
    if (trainingarray[i].Origin == 'DEN') {xvariables[61]=1;} else {xvariables[61]=0;}
    if (trainingarray[i].Origin == 'SFO') {xvariables[62]=1;} else {xvariables[62]=0;}
    if (trainingarray[i].Origin == 'LAS') {xvariables[63]=1;} else {xvariables[63]=0;}
    if (trainingarray[i].Origin == 'SEA') {xvariables[64]=1;} else {xvariables[64]=0;}
    if (trainingarray[i].Origin == 'CLT') {xvariables[65]=1;} else {xvariables[65]=0;}
    if (trainingarray[i].Origin == 'PHX') {xvariables[66]=1;} else {xvariables[66]=0;}
    if (trainingarray[i].Origin == 'MIA') {xvariables[67]=1;} else {xvariables[67]=0;}
    if (trainingarray[i].Origin == 'MCO') {xvariables[68]=1;} else {xvariables[68]=0;}
    if (trainingarray[i].Origin == 'IAH') {xvariables[69]=1;} else {xvariables[69]=0;}
    if (trainingarray[i].Origin == 'EWR') {xvariables[70]=1;} else {xvariables[70]=0;}
    if (trainingarray[i].Origin == 'MSR') {xvariables[71]=1;} else {xvariables[71]=0;}
    if (trainingarray[i].Origin == 'BOS') {xvariables[72]=1;} else {xvariables[72]=0;}
    if (trainingarray[i].Origin == 'DTW') {xvariables[73]=1;} else {xvariables[73]=0;}
    if (trainingarray[i].Origin == 'LGA') {xvariables[74]=1;} else {xvariables[74]=0;}
    if (trainingarray[i].Origin == 'PHL') {xvariables[75]=1;} else {xvariables[75]=0;}
    if (trainingarray[i].Dest == 'ATL') {xvariables[76]=1;} else {xvariables[76]=0;}
    if (trainingarray[i].Dest == 'LAX') {xvariables[77]=1;} else {xvariables[77]=0;}
    if (trainingarray[i].Dest == 'ORD') {xvariables[78]=1;} else {xvariables[78]=0;}
    if (trainingarray[i].Dest == 'DFW') {xvariables[79]=1;} else {xvariables[79]=0;}
    if (trainingarray[i].Dest == 'JFK') {xvariables[80]=1;} else {xvariables[80]=0;}
    if (trainingarray[i].Dest == 'DEN') {xvariables[81]=1;} else {xvariables[81]=0;}
    if (trainingarray[i].Dest == 'SFO') {xvariables[82]=1;} else {xvariables[82]=0;}
    if (trainingarray[i].Dest == 'LAS') {xvariables[83]=1;} else {xvariables[83]=0;}
    if (trainingarray[i].Dest == 'SEA') {xvariables[84]=1;} else {xvariables[84]=0;}
    if (trainingarray[i].Dest == 'CLT') {xvariables[85]=1;} else {xvariables[85]=0;}
    if (trainingarray[i].Dest == 'PHX') {xvariables[86]=1;} else {xvariables[86]=0;}
    if (trainingarray[i].Dest == 'MIA') {xvariables[87]=1;} else {xvariables[87]=0;}
    if (trainingarray[i].Dest == 'MCO') {xvariables[88]=1;} else {xvariables[88]=0;}
    if (trainingarray[i].Dest == 'IAH') {xvariables[89]=1;} else {xvariables[89]=0;}
    if (trainingarray[i].Dest == 'EWR') {xvariables[90]=1;} else {xvariables[90]=0;}
    if (trainingarray[i].Dest == 'MSR') {xvariables[91]=1;} else {xvariables[91]=0;}
    if (trainingarray[i].Dest == 'BOS') {xvariables[92]=1;} else {xvariables[92]=0;}
    if (trainingarray[i].Dest == 'DTW') {xvariables[93]=1;} else {xvariables[93]=0;}
    if (trainingarray[i].Dest == 'LGA') {xvariables[94]=1;} else {xvariables[94]=0;}
    if (trainingarray[i].Dest == 'PHL') {xvariables[95]=1;} else {xvariables[95]=0;}



    xtrain.push(xvariables);
}

const x = xtrain;
const y = ytrain;
const mlr = new MLR(x,y);

fs.writeFileSync('./coefficients.js', 'data='+JSON.stringify(mlr.weights));



//last weight is the intercept 
//next step: using test set, find average over/underestimation