//this is the actual server file 
var fs = require('fs');
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var tree =  require('./decisiontreeedited.js');

var urlecondedParser = bodyParser.urlencoded({ extended: false});

function traindata (){
    console.log('training the data');
    tree.createTree();
}

function getPrediction(arg1, arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12){
    console.log('getPrediction');
    return tree.predict(arg1,arg2,arg3,arg4,arg5,arg6,arg7,arg8,arg9,arg10,arg11,arg12);
}

app.use(express.static('sourcehtml'));

app.post('/index.html',urlecondedParser, function(req,res){
    /*
    if (req.body.Origin === req.body.Dest){
        alert('Origin and destination airport must be different!');
        return;
    }
    if (req.body.date === ''){
        alert('Date field cannot be left blank!');
        return; 
    }
    */    

    //average values for weather
    req.body.Awnd = 8.944533067417542;
    req.body.Snow = 0.002794054724933923;
    req.body.Snwd = 0.01523188454173861;
    req.body.Tavg = 62.15766267422065;
    req.body.Tmax = 71.61481493844431;
    req.body.Tmin = 53.35696533642452;
   
    var year = (req.body.date[0]+req.body.date[1]+req.body.date[2]+req.body.date[3]);
    var month = 0;
    var day = 0;

    if (req.body.date[5]===0) {month = Number(req.body.date[6]);}
    else {month = Number(req.body.date[5].toString()+req.body.date[6].toString());}

    if (req.body.date[8]===0) {month = Number(req.body.date[9]);}
    else {day = Number(req.body.date[8].toString()+req.body.date[9].toString());}

    var newDate = new Date(year,month-1,day); //month 0 refers to jan 
    
    if (newDate.getDay()===0){actualDay = 7;}
    else {actualDay = newDate.getDay();}

    req.body.day = actualDay.toString();
    req.body.month = month.toString();

    if (req.body.Hour[0]==='0'){req.body.Hour=req.body.Hour[1];}
    else {req.body.Hour=req.body.Hour[0]+req.body.Hour[1];}

    console.log(req.body);
    console.log(req.body.Awnd, req.body.carrier,req.body.day,req.body.Hour,req.body.Dest,req.body.month,req.body.Origin,req.body.Snow,req.body.Snwd,req.body.Tavg,req.body.Tmax,req.body.Tmin);
    var responseString = getPrediction(req.body.Awnd, req.body.carrier,req.body.day,req.body.Hour,req.body.Dest,req.body.month,req.body.Origin,req.body.Snow,req.body.Snwd,req.body.Tavg,req.body.Tmax,req.body.Tmin);
    console.log(responseString);

    fs.writeFileSync('./sourcehtml/prediction.js', 'prediction='+ responseString);
    fs.writeFileSync('./sourcehtml/parameters.js', 'parameters='+ JSON.stringify(req.body));
    res.redirect('./prediction.html');

});

traindata();
console.log('tree created');

app.listen(8081);  
