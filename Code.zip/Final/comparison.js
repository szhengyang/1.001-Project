data=[[-0.6132337926354212],[-1.0758081248265514],[5.167381570913562],[-0.18735868656636973],[2.8486462054328756],[-1.1674410687013295],[2.5620107400216985],[-0.2933751598057442],[0.14670648632298192],[0.11421564503984798],[1.4847011810112054],[14.323679795977077],[0.6778780807993526],[-2.591426755004637],[0.20414147857258266],[4.132353885994847],[3.2400847077261608],[5.953094838566024],[5.979211633524346],[2.6781059102234237],[-2.72178533865175],[-2.073065522192103],[-5.867811127093759],[-2.076584948918404],[-2.2082699651745273e-13],[3.404757733828106e-13],[-3.2311228153958014e-13],[-1.234644336028877e-13],[-7.816369164460289e-13],[3.5189021032679413e-13],[-1.8400197841721107e-14],[0.33470848161892597],[-2.2121473991211573],[-3.3131670763282277],[-4.481239860101736],[-1.1900411157246474e-13],[-5.277032203091188],[-7.548330796473096],[-6.836198289060158],[-4.925361581537143],[-2.863849019347102],[-2.0730014991838126],[-1.4003603462153913],[0.32899664612948526],[0.7511925636994938],[1.7054922357089324],[2.931457990348277],[4.187421952617844],[5.273565646577503],[7.3581596965858465],[8.591329479001146],[8.342372991069498],[6.339127444745001],[3.8604948853588548],[1.2711267182978683],[-2.4758533361301205],[3.053176254143489],[3.4772685029340353],[3.8152589852009187],[4.182922686385628],[4.733257754068341],[4.242028511401136],[5.764712181455411],[5.201319714818107],[2.0140984930879173],[4.169556874064377],[4.2776039947467694],[5.053391123816715],[4.822041538307559],[4.161062947573565],[7.33057106942909],[-7.02629511932741e-14],[3.4165103212814487],[0.9757353498417435],[3.886332814544117],[4.452274080372775],[1.3926496663342518],[3.356083250927542],[3.086219978643912],[2.1653545645339007],[10.095058688240135],[0.4603296073067518],[9.648737979002524],[0.5934979119347081],[1.0156173443618746],[1.0938111875629044],[0.048049152062980695],[3.884730093189382],[1.6512542741392855],[1.3698849469879815],[11.580290885453769],[0],[4.833482786268255],[0.553958206445239],[6.470858778604344],[2.9909384334491422],[7.5341968435358115]];

//97 coefficients, the last is the intercept

var fs = require('fs');

var jan = require('./jan.json');
var feb = require('./feb.json');
var mar = require('./mar.json');
var apr = require('./apr.json');
var may = require('./may.json');
var jun = require('./jun.json');
var jul = require('./jul.json');
var aug = require('./aug.json');
var sep = require('./sep.json');
var oct = require('./oct.json');
var nov = require('./nov.json');
var dec = require('./dec.json');

var compiled = jan.concat(feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec);

for (i=0;i<compiled.length;i++){
    if (compiled[i].CrsDepTime.length<=2) {compiled[i].depHr = 0;}
    else if (compiled[i].CrsDepTime.length==3) {compiled[i].depHr = compiled[i].CrsDepTime[0];}
    else if (compiled[i].CrsDepTime.length==4) {compiled[i].depHr = compiled[i].CrsDepTime[0]+compiled[i].CrsDepTime[1];}
}


var testarray = [];
for (i=1;i<compiled.length;i+=2){
    testarray.push(compiled[i]);
}

var ytest = [];
for (i=0;i<testarray.length;i++){
    ytest[i]=Number(testarray[i].ArrDelayNew);
}

var xtest = [];
for (i=0;i<testarray.length;i++){
    xvariables = [];
    if (testarray[i].Carrier == 'AA') {xvariables[0]=1;} else {xvariables[0]=0;}
    if (testarray[i].Carrier == 'AS') {xvariables[1]=1;} else {xvariables[1]=0;}
    if (testarray[i].Carrier == 'B6') {xvariables[2]=1;} else {xvariables[2]=0;}
    if (testarray[i].Carrier == 'DL') {xvariables[3]=1;} else {xvariables[3]=0;}
    if (testarray[i].Carrier == 'NK') {xvariables[4]=1;} else {xvariables[4]=0;}
    if (testarray[i].Carrier == 'UA') {xvariables[5]=1;} else {xvariables[5]=0;}
    if (testarray[i].Carrier == 'WN') {xvariables[6]=1;} else {xvariables[6]=0;}
    xvariables[7]=Number(testarray[i].Tmax);
    xvariables[8]=Number(testarray[i].Tmin);
    xvariables[9]=Number(testarray[i].Tavg);
    xvariables[10]=Number(testarray[i].Snwd);
    xvariables[11]=Number(testarray[i].Snow);
    if (testarray[i].Month == '1') {xvariables[12]=1;} else {xvariables[12]=0;}
    if (testarray[i].Month == '2') {xvariables[13]=1;} else {xvariables[13]=0;}
    if (testarray[i].Month == '3') {xvariables[14]=1;} else {xvariables[14]=0;}
    if (testarray[i].Month == '4') {xvariables[15]=1;} else {xvariables[15]=0;}
    if (testarray[i].Month == '5') {xvariables[16]=1;} else {xvariables[16]=0;}
    if (testarray[i].Month == '6') {xvariables[17]=1;} else {xvariables[17]=0;}
    if (testarray[i].Month == '7') {xvariables[18]=1;} else {xvariables[18]=0;}
    if (testarray[i].Month == '8') {xvariables[19]=1;} else {xvariables[19]=0;}
    if (testarray[i].Month == '9') {xvariables[20]=1;} else {xvariables[20]=0;}
    if (testarray[i].Month == '10') {xvariables[21]=1;} else {xvariables[21]=0;}
    if (testarray[i].Month == '11') {xvariables[22]=1;} else {xvariables[22]=0;}
    if (testarray[i].Month == '12') {xvariables[23]=1;} else {xvariables[23]=0;}
    if (testarray[i].DayofWeek == '1') {xvariables[24]=1;} else {xvariables[24]=0;}
    if (testarray[i].DayofWeek == '2') {xvariables[25]=1;} else {xvariables[25]=0;}
    if (testarray[i].DayofWeek == '3') {xvariables[26]=1;} else {xvariables[26]=0;}
    if (testarray[i].DayofWeek == '4') {xvariables[27]=1;} else {xvariables[27]=0;}
    if (testarray[i].DayofWeek == '5') {xvariables[28]=1;} else {xvariables[28]=0;}
    if (testarray[i].DayofWeek == '6') {xvariables[29]=1;} else {xvariables[29]=0;}
    if (testarray[i].DayofWeek == '7') {xvariables[30]=1;} else {xvariables[30]=0;}
    xvariables[31]=Number(testarray[i].Awnd);
    if (testarray[i].depHr == '0') {xvariables[32]=1;} else {xvariables[32]=0;}
    if (testarray[i].depHr == '1') {xvariables[33]=1;} else {xvariables[33]=0;}
    if (testarray[i].depHr == '2') {xvariables[34]=1;} else {xvariables[34]=0;}
    if (testarray[i].depHr == '3') {xvariables[35]=1;} else {xvariables[35]=0;}
    if (testarray[i].depHr == '4') {xvariables[36]=1;} else {xvariables[36]=0;}
    if (testarray[i].depHr == '5') {xvariables[37]=1;} else {xvariables[37]=0;}
    if (testarray[i].depHr == '6') {xvariables[38]=1;} else {xvariables[38]=0;}
    if (testarray[i].depHr == '7') {xvariables[39]=1;} else {xvariables[39]=0;}
    if (testarray[i].depHr == '8') {xvariables[40]=1;} else {xvariables[40]=0;}
    if (testarray[i].depHr == '9') {xvariables[41]=1;} else {xvariables[41]=0;}
    if (testarray[i].depHr == '10') {xvariables[42]=1;} else {xvariables[42]=0;}
    if (testarray[i].depHr == '11') {xvariables[43]=1;} else {xvariables[43]=0;}
    if (testarray[i].depHr == '12') {xvariables[44]=1;} else {xvariables[44]=0;}
    if (testarray[i].depHr == '13') {xvariables[45]=1;} else {xvariables[45]=0;}
    if (testarray[i].depHr == '14') {xvariables[46]=1;} else {xvariables[46]=0;}
    if (testarray[i].depHr == '15') {xvariables[47]=1;} else {xvariables[47]=0;}
    if (testarray[i].depHr == '16') {xvariables[48]=1;} else {xvariables[48]=0;}
    if (testarray[i].depHr == '17') {xvariables[49]=1;} else {xvariables[49]=0;}
    if (testarray[i].depHr == '18') {xvariables[50]=1;} else {xvariables[50]=0;}
    if (testarray[i].depHr == '19') {xvariables[51]=1;} else {xvariables[51]=0;}
    if (testarray[i].depHr == '20') {xvariables[52]=1;} else {xvariables[52]=0;}
    if (testarray[i].depHr == '21') {xvariables[53]=1;} else {xvariables[53]=0;}
    if (testarray[i].depHr == '22') {xvariables[54]=1;} else {xvariables[54]=0;}
    if (testarray[i].depHr == '23') {xvariables[55]=1;} else {xvariables[55]=0;}
    if (testarray[i].Origin == 'ATL') {xvariables[56]=1;} else {xvariables[56]=0;}
    if (testarray[i].Origin == 'LAX') {xvariables[57]=1;} else {xvariables[57]=0;}
    if (testarray[i].Origin == 'ORD') {xvariables[58]=1;} else {xvariables[58]=0;}
    if (testarray[i].Origin == 'DFW') {xvariables[59]=1;} else {xvariables[59]=0;}
    if (testarray[i].Origin == 'JFK') {xvariables[60]=1;} else {xvariables[60]=0;}
    if (testarray[i].Origin == 'DEN') {xvariables[61]=1;} else {xvariables[61]=0;}
    if (testarray[i].Origin == 'SFO') {xvariables[62]=1;} else {xvariables[62]=0;}
    if (testarray[i].Origin == 'LAS') {xvariables[63]=1;} else {xvariables[63]=0;}
    if (testarray[i].Origin == 'SEA') {xvariables[64]=1;} else {xvariables[64]=0;}
    if (testarray[i].Origin == 'CLT') {xvariables[65]=1;} else {xvariables[65]=0;}
    if (testarray[i].Origin == 'PHX') {xvariables[66]=1;} else {xvariables[66]=0;}
    if (testarray[i].Origin == 'MIA') {xvariables[67]=1;} else {xvariables[67]=0;}
    if (testarray[i].Origin == 'MCO') {xvariables[68]=1;} else {xvariables[68]=0;}
    if (testarray[i].Origin == 'IAH') {xvariables[69]=1;} else {xvariables[69]=0;}
    if (testarray[i].Origin == 'EWR') {xvariables[70]=1;} else {xvariables[70]=0;}
    if (testarray[i].Origin == 'MSR') {xvariables[71]=1;} else {xvariables[71]=0;}
    if (testarray[i].Origin == 'BOS') {xvariables[72]=1;} else {xvariables[72]=0;}
    if (testarray[i].Origin == 'DTW') {xvariables[73]=1;} else {xvariables[73]=0;}
    if (testarray[i].Origin == 'LGA') {xvariables[74]=1;} else {xvariables[74]=0;}
    if (testarray[i].Origin == 'PHL') {xvariables[75]=1;} else {xvariables[75]=0;}
    if (testarray[i].Dest == 'ATL') {xvariables[76]=1;} else {xvariables[76]=0;}
    if (testarray[i].Dest == 'LAX') {xvariables[77]=1;} else {xvariables[77]=0;}
    if (testarray[i].Dest == 'ORD') {xvariables[78]=1;} else {xvariables[78]=0;}
    if (testarray[i].Dest == 'DFW') {xvariables[79]=1;} else {xvariables[79]=0;}
    if (testarray[i].Dest == 'JFK') {xvariables[80]=1;} else {xvariables[80]=0;}
    if (testarray[i].Dest == 'DEN') {xvariables[81]=1;} else {xvariables[81]=0;}
    if (testarray[i].Dest == 'SFO') {xvariables[82]=1;} else {xvariables[82]=0;}
    if (testarray[i].Dest == 'LAS') {xvariables[83]=1;} else {xvariables[83]=0;}
    if (testarray[i].Dest == 'SEA') {xvariables[84]=1;} else {xvariables[84]=0;}
    if (testarray[i].Dest == 'CLT') {xvariables[85]=1;} else {xvariables[85]=0;}
    if (testarray[i].Dest == 'PHX') {xvariables[86]=1;} else {xvariables[86]=0;}
    if (testarray[i].Dest == 'MIA') {xvariables[87]=1;} else {xvariables[87]=0;}
    if (testarray[i].Dest == 'MCO') {xvariables[88]=1;} else {xvariables[88]=0;}
    if (testarray[i].Dest == 'IAH') {xvariables[89]=1;} else {xvariables[89]=0;}
    if (testarray[i].Dest == 'EWR') {xvariables[90]=1;} else {xvariables[90]=0;}
    if (testarray[i].Dest == 'MSR') {xvariables[91]=1;} else {xvariables[91]=0;}
    if (testarray[i].Dest == 'BOS') {xvariables[92]=1;} else {xvariables[92]=0;}
    if (testarray[i].Dest == 'DTW') {xvariables[93]=1;} else {xvariables[93]=0;}
    if (testarray[i].Dest == 'LGA') {xvariables[94]=1;} else {xvariables[94]=0;}
    if (testarray[i].Dest == 'PHL') {xvariables[95]=1;} else {xvariables[95]=0;}

    xtest.push(xvariables);
}


yResults = [];
for (i=0;i<xtest.length;i++){
    var yValue = 0;
    for(j=0;j<96;j++){
        yValue += data[j][0]*xtest[i][j];
    }
    yResults[i]=yValue+data[96][0];
}


//compare with actual values from ytest

var absDiffSum = 0;
var posCount = 0;
var negCount = 0;
var exactCount = 0;
var delayCount = 0;
var samepredict = 0;

for (i=0;i<xtest.length;i++){
    absDiffSum += Math.abs(yResults[i]-ytest[i]);
    
    if (yResults[i]-ytest[i]>0) {posCount +=1;}
    else if ((yResults[i]-ytest[i]<0)) {negCount +=1;}
    else {exactCount += 1;}

    if (yResults[i]>=15 && ytest[i]>=15){samepredict+=1;}
}
var absDiffAvg = absDiffSum/xtest.length;

var ytestSum = 0;
for (i=0;i<ytest.length;i++){
    ytestSum += ytest[i];

    if (ytest[i]>=15)    {delayCount += 1;}
}
var ytestAvg = ytestSum/ytest.length;

console.log(posCount,negCount,exactCount);
console.log(delayCount, samepredict, samepredict/delayCount);
console.log(absDiffAvg);
console.log(ytestAvg);

var comparisonarray = [];
for (i=0;i<ytest.length;i++){
    tempobj = {};
    tempobj.ytest = ytest[i];
    tempobj.yResults = yResults[i];
    comparisonarray[i]=tempobj;
}


fs.writeFileSync('./comparison.json', JSON.stringify(comparisonarray));

/*
505791 153287 0
132250 80524 
19.162386164372908
13.827015922242891

model performance: 
tends to overpredict delay most of the time
about 61% accuracy in terms of predicting if a flight is delayed
average absolute difference is high due to significant number of points having extremely high delays 
in tableau, we see that in terms of correctly predicting a delayed flight, greater accuracy for higher delay predictions (more blue points)
*/
