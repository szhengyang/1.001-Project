var fs = require('fs');
const csvFilePath1='./jan.csv';
const csvFilePath2='./feb.csv';
const csvFilePath3='./mar.csv';
const csvFilePath4='./apr.csv';
const csvFilePath5='./may.csv';
const csvFilePath6='./jun.csv';
const csvFilePath7='./jul.csv';
const csvFilePath8='./aug.csv';
const csvFilePath9='./sep.csv';
const csvFilePath10='./oct.csv';
const csvFilePath11='./nov.csv';
const csvFilePath12='./dec.csv';


const csv=require('csvtojson');

var compiledjan = [];
var compiledfeb = [];
var compiledmar = [];
var compiledapr = [];
var compiledmay = [];
var compiledjun = [];
var compiledjul = [];
var compiledaug = [];
var compiledsep = [];
var compiledoct = [];
var compilednov = [];
var compileddec = [];

//jan data
csv()
.fromFile(csvFilePath1)
.on('json',(jsonObj)=>{
	// combine csv header row and csv line to a json object
    compiledjan.push(jsonObj);   
})
.on('done',(error)=>{
    fs.appendFileSync('./jan.json', JSON.stringify(compiledjan));
	console.log('end');
});

//feb data
csv()
.fromFile(csvFilePath2)
.on('json',(jsonObj)=>{
    compiledfeb.push(jsonObj);    
})
.on('done',(error)=>{
    fs.appendFileSync('./feb.json', JSON.stringify(compiledfeb));
	console.log('end');
});

//mar data
csv()
.fromFile(csvFilePath3)
.on('json',(jsonObj)=>{
    compiledmar.push(jsonObj);   
})
.on('done',(error)=>{
    fs.appendFileSync('./mar.json', JSON.stringify(compiledmar));
	console.log('end');
});

//apr data
csv()
.fromFile(csvFilePath4)
.on('json',(jsonObj)=>{
    compiledapr.push(jsonObj);   
})
.on('done',(error)=>{
    fs.appendFileSync('./apr.json', JSON.stringify(compiledapr));
	console.log('end');
});

//may data
csv()
.fromFile(csvFilePath5)
.on('json',(jsonObj)=>{
    compiledmay.push(jsonObj);
})
.on('done',(error)=>{
    fs.appendFileSync('./may.json', JSON.stringify(compiledmay));
	console.log('end');
});

//june data
csv()
.fromFile(csvFilePath6)
.on('json',(jsonObj)=>{
    compiledjun.push(jsonObj);    
})
.on('done',(error)=>{
    fs.appendFileSync('./jun.json', JSON.stringify(compiledjun));
	console.log('end');
});

//july data
csv()
.fromFile(csvFilePath7)
.on('json',(jsonObj)=>{
    compiledjul.push(jsonObj);    
})
.on('done',(error)=>{
    fs.appendFileSync('./jul.json', JSON.stringify(compiledjul));
	console.log('end');
});

//august data
csv()
.fromFile(csvFilePath8)
.on('json',(jsonObj)=>{
    compiledaug.push(jsonObj);
    
})
.on('done',(error)=>{
    fs.appendFileSync('./aug.json', JSON.stringify(compiledaug));
	console.log('end');
});

//september data
csv()
.fromFile(csvFilePath9)
.on('json',(jsonObj)=>{
    compiledsep.push(jsonObj);    
})
.on('done',(error)=>{
    fs.appendFileSync('./sep.json', JSON.stringify(compiledsep));
	console.log('end');
});

//october data
csv()
.fromFile(csvFilePath10)
.on('json',(jsonObj)=>{
    compiledoct.push(jsonObj);   
})
.on('done',(error)=>{
    fs.appendFileSync('./oct.json', JSON.stringify(compiledoct));
	console.log('end');
});

//november data
csv()
.fromFile(csvFilePath11)
.on('json',(jsonObj)=>{
    compilednov.push(jsonObj);    
})
.on('done',(error)=>{
    fs.appendFileSync('./nov.json', JSON.stringify(compilednov));
	console.log('end');
});

//december data 
csv()
.fromFile(csvFilePath12)
.on('json',(jsonObj)=>{
    compileddec.push(jsonObj);
})
.on('done',(error)=>{
    fs.appendFileSync('./dec.json', JSON.stringify(compileddec));
	console.log('end');
});




